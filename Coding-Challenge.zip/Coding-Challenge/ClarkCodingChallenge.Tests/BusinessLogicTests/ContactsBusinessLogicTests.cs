using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ClarkCodingChallenge.Tests.BusinessLogicTests
{
    [TestClass]
    public class ContactsBusinessLogicTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
