﻿namespace ClarkCodingChallenge.BusinessLogic
{
    public class ContactsService
    {
        //TODO: Place business logic for contact here
    }
}
