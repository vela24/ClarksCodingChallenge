﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ClarkCodingChallenge.Models;
using System.Collections.Generic;
using System.Web;


namespace ClarkCodingChallenge.Controllers
{
    public class ContactsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }



        public ActionResult Email()
        {


            return View();
        }
        [HttpPost]
        public ActionResult Email(Email em)
        {
            List<Email> userList = new List<Email>();
            if (ModelState.IsValid)
            {
/*                ViewData["FirstName"] = em.FirstName;
                ViewData["LastName"] = em.LastName;
                ViewData["Email"] = em.EmailAddress;*/

                userList.Add(em);

               /* ViewData["List"] = userList;*/
                TempData["ContactList"] = userList;
                return View("Success");

            }

            return View(em);

        }
        public ActionResult Success()
        {

            return View();
        }

        public ActionResult ContactList()
        {

            List<Email> userList = (List<Email>)TempData["ContactList"];
            ViewBag.Collection = userList;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
