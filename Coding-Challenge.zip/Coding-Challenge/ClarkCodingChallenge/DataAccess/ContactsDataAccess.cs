﻿namespace ClarkCodingChallenge.DataAccess
{
    public class ContactsDataAccess
    {
        //TODO: Place data access code here
    }
}
